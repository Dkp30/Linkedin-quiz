// Q1
function trueOrNotTrue(first, second) {
  if (first !== second) {
    return true;
  }
}
console.log(trueOrNotTrue(5, 10));

// Q3
function addTax(total) {
  return total * 1.05;
}

console.log(addTax(50));

// Q9
discountPrice = function (price) {
  return price * 0.85;
};

console.log(discountPrice(50));
