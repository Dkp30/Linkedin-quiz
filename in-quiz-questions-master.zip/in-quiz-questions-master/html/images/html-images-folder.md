# Store images for HTML quiz in this folder.
